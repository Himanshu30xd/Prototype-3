# TalentDesk responsive update

## Files
- `index.html` — Recruitment / job listings
- `import-export.html` — Candidate and job CSV import/export
- `event.html` — Hiring events and interviews
- `style.css` — Shared responsive styling
- `app.js` — Shared front-end behaviour

## Run it
Keep all five files in the same folder and open `index.html`, or deploy the folder to a static host. Navigation and assets use consistent filenames.

## Responsive changes
- Desktop/tablet sidebar navigation; mobile slide-out menu with scrim
- Flexible dashboard statistics, cards, forms, and tables for narrow screens
- Touch-friendly controls, smaller-screen spacing, reduced-motion support, and viewport-safe layout
- Fixed CSS/HTML filename mismatch (`style.css` and exact page filenames)
- Candidate CSV import checks malformed email addresses and duplicate emails; job import skips duplicate titles
- Optional application cover note is now stored with the candidate record

## Important production limitation
This is still a front-end prototype: records are stored in each browser's `localStorage`. They do **not** sync between devices or between different company users. Do not put real candidate personal data into this version. To make it genuinely production-ready, connect a secure shared backend/database and authentication/organization permissions, configure backups and privacy controls, and test deployment. No backend credentials were provided, so this update does not pretend that cloud syncing or company data isolation is already active.
